/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.AtmCard;
import entity.DepositAccount;
import java.util.List;
import javax.ejb.Remote;
import util.exception.AtmCardExistException;
import util.exception.AtmCardInvalidPinException;
import util.exception.AtmCardNotFoundException;
import util.exception.AtmCardPinMismatchException;
import util.exception.CustomerNotFoundException;
import util.exception.DeleteAtmCardException;
import util.exception.DepositAccountMismatchCustomerException;
import util.exception.DepositAccountNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Remote
public interface AtmCardSessionBeanRemote {
    
    public AtmCard issueNewAtmCard(AtmCard newAtmCard, String customerIdentificationNumber, List<Long> depositAccountIds) throws AtmCardExistException, UnknownPersistenceException, CustomerNotFoundException, DepositAccountNotFoundException, DepositAccountMismatchCustomerException;

    public AtmCard retrieveAtmCardByAtmCardId(Long atmCardId) throws AtmCardNotFoundException;

    public AtmCard retrieveAtmCardByCardNumber(String cardNumber) throws AtmCardNotFoundException;
    
    public void deleteAtmCard(Long atmCardId) throws AtmCardNotFoundException, DeleteAtmCardException;
    
    public void changeAtmCardPin(Long atmCardId, String oldPin, String newPin) throws AtmCardNotFoundException, AtmCardPinMismatchException;

    public void AtmCardVerifyPin(AtmCard atmCard, String pin) throws AtmCardInvalidPinException;
    
    public List<DepositAccount> retrieveDepositAccountsByAtmCardId(Long atmCardId) throws AtmCardNotFoundException;
    
}
