/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.exception;

/**
 *
 * @author aaronf
 */
public class AtmCardPinMismatchException extends Exception {

    /**
     * Creates a new instance of <code>AtmCardPinMismatchException</code>
     * without detail message.
     */
    public AtmCardPinMismatchException() {
    }

    /**
     * Constructs an instance of <code>AtmCardPinMismatchException</code> with
     * the specified detail message.
     *
     * @param msg the detail message.
     */
    public AtmCardPinMismatchException(String msg) {
        super(msg);
    }
}
