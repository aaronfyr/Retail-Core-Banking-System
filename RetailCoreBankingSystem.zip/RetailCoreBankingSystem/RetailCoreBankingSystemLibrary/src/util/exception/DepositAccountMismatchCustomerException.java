/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util.exception;

/**
 *
 * @author aaronf
 */
public class DepositAccountMismatchCustomerException extends Exception {

    /**
     * Creates a new instance of
     * <code>DepositAccountMismatchCustomerException</code> without detail
     * message.
     */
    public DepositAccountMismatchCustomerException() {
    }

    /**
     * Constructs an instance of
     * <code>DepositAccountMismatchCustomerException</code> with the specified
     * detail message.
     *
     * @param msg the detail message.
     */
    public DepositAccountMismatchCustomerException(String msg) {
        super(msg);
    }
}
