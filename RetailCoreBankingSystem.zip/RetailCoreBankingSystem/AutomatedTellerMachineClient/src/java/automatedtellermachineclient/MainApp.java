/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package automatedtellermachineclient;

import ejb.session.stateless.AtmCardSessionBeanRemote;
import entity.AtmCard;
import entity.DepositAccount;
import java.util.List;
import java.util.Scanner;
import util.exception.AtmCardInvalidPinException;
import util.exception.AtmCardNotFoundException;
import util.exception.AtmCardPinMismatchException;

/**
 *
 * @author aaronf
 */
public class MainApp {
    
    private AtmCardSessionBeanRemote atmCardSessionBeanRemote;
    private AtmCard atmCard;
    
    public MainApp() {
    }

    public MainApp(AtmCardSessionBeanRemote atmCardSessionBeanRemote) {
        this.atmCardSessionBeanRemote = atmCardSessionBeanRemote;
    }
    
    public void runApp() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        
        while (true) {
            System.out.println("*** Welcome to RCBS ATM ***\n");
            System.out.println("1: Insert ATM card");
            System.out.println("2: Exit\n");
            response = 0;
            
            while (response < 1 || response > 2) {
                System.out.print("> ");
                
                response = scanner.nextInt();
                
                if (response == 1) {
                    try {
                        doInsertAtmCard();
                        System.out.println("\n *** ATM card is valid and successfully verified ***");
                        System.out.println("");
                        menuMain();
                    } catch (AtmCardNotFoundException ex) {
                        System.out.println("\nATM card number is invalid. " + ex.getMessage() + "\n");
                    } catch (AtmCardInvalidPinException ex) {
                        System.out.println("\nATM card pin is invalid. " + ex.getMessage() + "\n");
                    }
                } else if (response == 2) {
                    break;
                } else {
                    System.out.println("\nInvalid option, please try again!\n");    
                }
            }
            
            if(response == 2)
            {
                break;
            }
        }
    }
    
    private void menuMain() throws AtmCardNotFoundException {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;
        
        while (true) {
            
            System.out.println("*** Welcome to RCBS ATM ***\n");
            System.out.println("You are logged in as " + atmCard.getCustomer().getFirstName() + " " + atmCard.getCustomer().getLastName() + "\n");
            System.out.println("1: Change PIN");
            System.out.println("2: Enquire available balance");
            System.out.println("3: Logout\n");
            response = 0;
            while (response < 1 || response > 3) {
                System.out.print("> ");

                response = scanner.nextInt();

                if (response == 1) {
                    doChangePin();
                } else if (response == 2) {
                    doEnquireAvailableBalance();
                } else if (response == 3) {
                    break;
                } else {
                    System.out.println("\nInvalid option, please try again!\n");
                }
            }
            if (response == 3) {
                break;
            }
        }
    }
    
    private void doInsertAtmCard() throws AtmCardNotFoundException, AtmCardInvalidPinException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n*** ATM card has been inserted *** \n");
        System.out.print("Enter ATM card number > ");
        String cardNumber = scanner.nextLine().trim();
        AtmCard atmCardInserted = atmCardSessionBeanRemote.retrieveAtmCardByCardNumber(cardNumber);
        System.out.print("Enter ATM card pin > ");
        String atmPin = scanner.nextLine().trim();
        atmCardSessionBeanRemote.AtmCardVerifyPin(atmCardInserted, atmPin);
        this.atmCard = atmCardInserted;
    }
    
    private void doChangePin() {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n*** RCBS ATM :: Change PIN ***\n");
            System.out.print("Enter current PIN > ");
            String oldPin = scanner.nextLine().trim();
            atmCardSessionBeanRemote.AtmCardVerifyPin(atmCard, oldPin);
            System.out.print("Enter new PIN > ");
            String newPin = scanner.nextLine().trim();
            atmCardSessionBeanRemote.changeAtmCardPin(atmCard.getAtmCardId(), oldPin, newPin);
            System.out.println("\nPin has been changed successfully!\n");
        } catch (AtmCardNotFoundException | AtmCardInvalidPinException | AtmCardPinMismatchException ex) {
            System.out.println("\nAn error has occurred while changing ATM card pin: " + ex.getMessage() + "\n");
        }
    }
    
    private void doEnquireAvailableBalance() {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println("");
            System.out.println("\n*** RCBS ATM :: Balance Enquiry ***\n");
            List<DepositAccount> depositAccounts = atmCardSessionBeanRemote.retrieveDepositAccountsByAtmCardId(atmCard.getAtmCardId());
            System.out.println("\nWhich account would you like to enquire?\n");
            System.out.printf("%3s%20s%20s\n", "S/N", "Account Type", "Account Number");
            Integer serialNum = 0;
            
            for (DepositAccount depositAccount : depositAccounts) {
                serialNum++;
                System.out.printf("%3s%20s%20s\n", serialNum, depositAccount.getAccountType().toString(), depositAccount.getAccountNumber());
            }
            
            System.out.println("");
            System.out.print("Please choose account to enquire > ");
            Integer response = scanner.nextInt();
            
            if (response >= 1 && response <= serialNum) {
                System.out.println("\nYour available balance is $" + depositAccounts.get(response - 1).getAvailableBalance() + "\n");
            } else {
                System.out.println("\nInvalid option!\n");
            }
            
        } catch (AtmCardNotFoundException ex) {
            System.out.println("\nAn error has occurred while changing ATM card pin: " + ex.getMessage() + "\n");
        } 
    }
}

