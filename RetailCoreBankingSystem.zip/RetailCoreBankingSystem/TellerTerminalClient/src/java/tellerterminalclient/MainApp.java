/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tellerterminalclient;

import ejb.session.stateless.AtmCardSessionBeanRemote;
import ejb.session.stateless.CustomerSessionBeanRemote;
import ejb.session.stateless.DepositAccountSessionBeanRemote;
import entity.AtmCard;
import entity.Customer;
import entity.DepositAccount;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import util.enumeration.DepositAccountType;
import util.exception.AtmCardExistException;
import util.exception.AtmCardNotFoundException;
import util.exception.CustomerExistException;
import util.exception.CustomerNotFoundException;
import util.exception.DeleteAtmCardException;
import util.exception.DepositAccountExistException;
import util.exception.DepositAccountMismatchCustomerException;
import util.exception.DepositAccountNotFoundException;
import util.exception.InvalidLoginCredentialException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
public class MainApp {

    private CustomerSessionBeanRemote customerSessionBeanRemote;
    private DepositAccountSessionBeanRemote depositAccountSessionBeanRemote;
    private AtmCardSessionBeanRemote atmCardSessionBeanRemote;

    public MainApp() {
    }

    public MainApp(CustomerSessionBeanRemote customerSessionBeanRemote, DepositAccountSessionBeanRemote depositAccountSessionBeanRemote, AtmCardSessionBeanRemote atmCardSessionBeanRemote) {
        this();
        this.customerSessionBeanRemote = customerSessionBeanRemote;
        this.depositAccountSessionBeanRemote = depositAccountSessionBeanRemote;
        this.atmCardSessionBeanRemote = atmCardSessionBeanRemote;
    }

    public void runApp() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;

        while (true) {
            System.out.println("*** Welcome to RCBS Teller Terminal ***\n");
            System.out.println("1: Login");
            System.out.println("2: Exit\n");
            response = 0;

            while (response < 1 || response > 2) {
                System.out.print("> ");

                response = scanner.nextInt();

                if (response == 1) {
                    try {
                        doLogin();
                        System.out.println("\nLogin successfully!\n");
                        menuMain();
                    } catch (InvalidLoginCredentialException ex) {
                        System.out.println("\nLogin's credential is invalid. " + ex.getMessage() + "\n");
                    }
                } else if (response == 2) {
                    break;
                } else {
                    System.out.println("\nInvalid option, please try again!\n");
                }
            }

            if (response == 2) {
                break;
            }
        }
    }

    private void menuMain() {
        Scanner scanner = new Scanner(System.in);
        Integer response = 0;

        while (true) {

            System.out.println("\n*** Welcome to RCBS Teller Terminal ***\n");
            System.out.println("You are logged in as " + "Employee" + "\n");
            System.out.println("1: Create Customer");
            System.out.println("2: Open Deposit Account");
            System.out.println("3: Issue ATM Card");
            System.out.println("4: Logout\n");
            response = 0;

            while (response < 1 || response > 4) {
                System.out.print("> ");

                response = scanner.nextInt();

                if (response == 1) {
                    doCreateCustomer();
                } else if (response == 2) {
                    doOpenDepositAccount();
                } else if (response == 3) {
                    doIssueAtmCard();
                } else if (response == 4) {
                    break;
                } else {
                    System.out.println("\nInvalid option, please try again!\n");
                }
            }
            if (response == 4) {
                break;
            }
        }
    }
    
        private void doLogin() throws InvalidLoginCredentialException {
        Scanner scanner = new Scanner(System.in);
        String username = "";
        String password = "";

        System.out.println("*** RCBS Teller Terminal :: Login ***\n");
        System.out.print("Enter username > ");
        username = scanner.nextLine().trim();
        System.out.print("Enter password > ");
        password = scanner.nextLine().trim();

        if (username.length() > 0 && password.length() > 0) {
        } else {
            throw new InvalidLoginCredentialException("Missing login credential!");
        }
    }

    private void doCreateCustomer() {
        try {

            Scanner scanner = new Scanner(System.in);
            Customer newCustomer = new Customer();

            System.out.println("\n*** RCBS Teller Terminal :: Customer Creation ***\n");
            System.out.print("Enter first name > ");
            String firstName = scanner.nextLine().trim();
            newCustomer.setFirstName(firstName);
            System.out.print("Enter last name > ");
            String lastName = scanner.nextLine().trim();
            newCustomer.setLastName(lastName);
            System.out.print("Enter identification number > ");
            String identificationNumber = scanner.nextLine().trim();
            newCustomer.setIdentificationNumber(identificationNumber);
            System.out.print("Enter contact number > ");
            String contactNumber = scanner.nextLine().trim();
            newCustomer.setContactNumber(contactNumber);
            System.out.print("Enter address line 1 > ");
            String addressLine1 = scanner.nextLine().trim();
            newCustomer.setAddressLine1(addressLine1);
            System.out.print("Enter address line 2 > ");
            String addressLine2 = scanner.nextLine().trim();
            newCustomer.setAddressLine2(addressLine2);
            System.out.print("Enter postal code > ");
            String postalCode = scanner.nextLine().trim();
            newCustomer.setPostalCode(postalCode);

            customerSessionBeanRemote.createNewCustomer(newCustomer);
            System.out.println("\nCustomer has been successfully created!\n");
        } catch (CustomerExistException | UnknownPersistenceException ex) {
            System.out.println("\nAn unknown error has occurred while creating the new customer!: " + ex.getMessage() + "\n");
        }
    }

    private void doOpenDepositAccount() {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n*** RCBS Teller Terminal :: Open New Deposit Account ***\n");
            System.out.print("Enter customer identification number > ");
            String identificationNumber = scanner.nextLine().trim();
            Customer customer = customerSessionBeanRemote.retrieveCustomerByCustomerIdentificationNumber(identificationNumber);
            System.out.println("\n*** Open deposit account for " + customer.getFirstName() + " " + customer.getLastName() + " *** \n");

            DepositAccount depositAccount = new DepositAccount();
            System.out.print("Enter account number > ");
            String accountNumber = scanner.nextLine().trim();
            depositAccount.setAccountNumber(accountNumber);

            while (true) {
                System.out.print("Select account type (1: Savings, 2: Current) > ");
                Integer accountTypeOption = scanner.nextInt();

                if (accountTypeOption >= 1 && accountTypeOption <= 2) {
                    depositAccount.setAccountType(DepositAccountType.values()[accountTypeOption - 1]);
                    break;
                } else {
                    System.out.println("\nInvalid option, please try again!\n");
                }
            }

            System.out.print("Enter initial deposit amount > ");
            BigDecimal initialDeposit = scanner.nextBigDecimal();
            depositAccount.setAvailableBalance(initialDeposit);
            depositAccount.setLedgerBalance(depositAccount.getAvailableBalance());

            DepositAccount newDepositAccount = depositAccountSessionBeanRemote.createNewDepositAccount(depositAccount, identificationNumber);
            System.out.println("\nNew deposit account " + newDepositAccount.getAccountNumber() + " has been successfully created!\n");

        } catch (CustomerNotFoundException | DepositAccountExistException | UnknownPersistenceException ex) {
            System.out.println("\nAn error has occurred while opening a new deposit account!: " + ex.getMessage() + "\n");
        }
    }

    private void doIssueAtmCard() {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println("\n*** RCBS Teller Terminal :: ATM Card Issuance ***\n");
            System.out.print("Enter customer identification number > ");
            String identificationNumber = scanner.nextLine().trim();
            Customer customer = customerSessionBeanRemote.retrieveCustomerByCustomerIdentificationNumber(identificationNumber);
            if (customerSessionBeanRemote.retrieveDepositAccountsByCustomerIdentificationNumber(identificationNumber).isEmpty()) {
                System.out.println("\nSorry, customer do not own any deposit accounts. Please open one before issuing ATM card.\n");
                return;
            }
            System.out.println("\nIssuing ATM card for " + customer.getFirstName() + " " + customer.getLastName() + "\n");

            if (customer.getAtmCard() != null) {
                System.out.print("You cannot own more than 1 card, would you like to replace your existing card? (Enter Y to replace) > ");
                String replacementChoice = scanner.nextLine().trim();
                if (replacementChoice.equals("Y")) {
                    atmCardSessionBeanRemote.deleteAtmCard(customer.getAtmCard().getAtmCardId());
                    System.out.println("\nYour existing card has been deleted and cancelled.\n");
                } else {
                    System.out.println("\nExisting card has not been deleted.\n");
                    return;
                }
            }

            System.out.print("Enter card number > ");
            String cardNumber = scanner.nextLine().trim();
            System.out.print("Enter name on card > ");
            String nameOnCard = scanner.nextLine().trim();
            System.out.print("Enter pin number > ");
            String pinNumber = scanner.nextLine().trim();
            AtmCard atmCard = new AtmCard(cardNumber, nameOnCard, pinNumber);

            List<Long> depositAccountIds = new ArrayList<>();

            while (true) {
                for (DepositAccount depositAccount : customerSessionBeanRemote.retrieveDepositAccountsByCustomerIdentificationNumber(identificationNumber)) {
                    System.out.print("Do you want to link deposit account number " + depositAccount.getAccountNumber() + " to your card? (Enter Y to link) > ");
                    String linkChoice = scanner.nextLine().trim();
                    if (linkChoice.equals("Y")) {
                        depositAccountIds.add(depositAccount.getDepositAccountId());
                    }
                }

                if (!depositAccountIds.isEmpty()) {
                    AtmCard newAtmCard = atmCardSessionBeanRemote.issueNewAtmCard(atmCard, customer.getIdentificationNumber(), depositAccountIds);
                    System.out.println("\nATM card with card number " + newAtmCard.getCardNumber() + " has been issued to the customer.\n");
                    break;
                } else {
                    System.out.println("The ATM card must be associated with one or more deposit accounts.\n");
                }
            }
        } catch (CustomerNotFoundException | AtmCardNotFoundException | DeleteAtmCardException | AtmCardExistException | DepositAccountNotFoundException | DepositAccountMismatchCustomerException | UnknownPersistenceException ex) {
            System.out.println("\nAn error has occurred while issuing ATM card!: " + ex.getMessage() + "\n");
        }
    }

}
