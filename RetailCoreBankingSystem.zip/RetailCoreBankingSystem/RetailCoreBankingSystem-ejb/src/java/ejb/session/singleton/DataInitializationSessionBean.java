/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.singleton;

import ejb.session.stateless.AtmCardSessionBeanLocal;
import ejb.session.stateless.CustomerSessionBeanLocal;
import ejb.session.stateless.DepositAccountSessionBeanLocal;
import entity.AtmCard;
import entity.Customer;
import entity.DepositAccount;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import javax.ejb.LocalBean;
import javax.ejb.Startup;
import util.enumeration.DepositAccountType;
import util.exception.AtmCardExistException;
import util.exception.AtmCardNotFoundException;
import util.exception.CustomerExistException;
import util.exception.CustomerNotFoundException;
import util.exception.DepositAccountExistException;
import util.exception.DepositAccountMismatchCustomerException;
import util.exception.DepositAccountNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Singleton
@LocalBean
@Startup

public class DataInitializationSessionBean {

    @EJB
    private DepositAccountSessionBeanLocal depositAccountSessionBeanLocal;

    @EJB
    private AtmCardSessionBeanLocal atmCardSessionBeanLocal;

    @EJB
    private CustomerSessionBeanLocal customerSessionBeanLocal;
    
    
    
    
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    public DataInitializationSessionBean() {
    }
    
    @PostConstruct
    public void postConstruct()
    {
//        try
//        {
//            System.out.println("TRY STATEMENT ENTRY");
//            atmCardSessionBeanLocal.retrieveAtmCardByCardNumber("1001001001");
//            System.out.println("TRY STATEMENT EXIT");
//        }
//        catch(AtmCardNotFoundException ex)
//        {
//            System.out.println("CATCH STATEMENT ENTRY");
//            initializeData();
//        }
    }
    
    private void initializeData() {
//        try {
//            customerSessionBeanLocal.createNewCustomer(new Customer("Aaron", "Foo", "S12345678A", "91234567", "8 College Avenue East", "", "138615"));
//            Customer customer = customerSessionBeanLocal.retrieveCustomerByCustomerIdentificationNumber("S12345678A");
//            
//            depositAccountSessionBeanLocal.createNewDepositAccount(new DepositAccount("010-111-222", DepositAccountType.SAVINGS, new BigDecimal("10000"), new BigDecimal("0"), new BigDecimal("10000")), customer.getIdentificationNumber());
//            depositAccountSessionBeanLocal.createNewDepositAccount(new DepositAccount("020-222-333", DepositAccountType.SAVINGS, new BigDecimal("10000"), new BigDecimal("0"), new BigDecimal("10000")), customer.getIdentificationNumber());
//            List<DepositAccount> depositAccounts = customer.getDepositAccounts();
//            List<Long> depositAccountsId = new ArrayList<>();
//            for (DepositAccount depositAccount : depositAccounts) {
//                depositAccountsId.add(depositAccount.getDepositAccountId());
//            }
//            atmCardSessionBeanLocal.issueNewAtmCard(new AtmCard("1000020000", "Aaron", "123456"), customer.getIdentificationNumber(), depositAccountsId);
//            
//            
//        } catch(CustomerExistException | CustomerNotFoundException | DepositAccountExistException | DepositAccountNotFoundException | DepositAccountMismatchCustomerException | AtmCardExistException | UnknownPersistenceException ex) {
//            ex.printStackTrace();
//        }
    }
}
