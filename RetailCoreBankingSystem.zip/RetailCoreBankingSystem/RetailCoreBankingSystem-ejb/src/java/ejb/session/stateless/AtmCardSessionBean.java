/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.AtmCard;
import entity.Customer;
import entity.DepositAccount;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import util.exception.AtmCardExistException;
import util.exception.AtmCardInvalidPinException;
import util.exception.AtmCardNotFoundException;
import util.exception.AtmCardPinMismatchException;
import util.exception.CustomerNotFoundException;
import util.exception.DeleteAtmCardException;
import util.exception.DepositAccountMismatchCustomerException;
import util.exception.DepositAccountNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Stateless
public class AtmCardSessionBean implements AtmCardSessionBeanRemote, AtmCardSessionBeanLocal {

    @EJB
    private DepositAccountSessionBeanLocal depositAccountSessionBeanLocal;

    @EJB
    private CustomerSessionBeanLocal customerSessionBeanLocal;
    
    @PersistenceContext(unitName = "RetailCoreBankingSystem-ejbPU")
    private EntityManager em;

    public AtmCardSessionBean() {
    }
    

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    @Override
    public AtmCard issueNewAtmCard(AtmCard newAtmCard, String customerIdentificationNumber, List<Long> depositAccountIds) throws AtmCardExistException, UnknownPersistenceException, CustomerNotFoundException, DepositAccountNotFoundException, DepositAccountMismatchCustomerException {
        try {
            
            Customer customer = customerSessionBeanLocal.retrieveCustomerByCustomerIdentificationNumber(customerIdentificationNumber);
            newAtmCard.setCustomer(customer);
            newAtmCard.setEnabled(true);
            customer.setAtmCard(newAtmCard);
            
            for (Long depositAccountId : depositAccountIds) {
                DepositAccount depositAccount = depositAccountSessionBeanLocal.retrieveDepositAccountByDepositAccountId(depositAccountId);
                
                if (depositAccount.getCustomer().equals(customer)) {
                    depositAccount.setAtmCard(newAtmCard);
                    newAtmCard.getDepositAccounts().add(depositAccount);
                } else {
                    throw new DepositAccountMismatchCustomerException("Chosen deposit account holder does not match ATM card holder");
                }
            }
            em.persist(newAtmCard);
            em.flush();
            em.refresh(newAtmCard);
            
            return newAtmCard;
            
        } catch (PersistenceException ex) {
            if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                    throw new AtmCardExistException("Atm card with the same card number already exist");
                }
                else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }
            else {
                throw new UnknownPersistenceException(ex.getMessage());
            }
        } catch (CustomerNotFoundException ex) {
            throw new CustomerNotFoundException("Unable to issue new ATM card as the customer record does not exist");
        } catch (DepositAccountNotFoundException ex) {
            throw new DepositAccountNotFoundException("Unable to issue new ATM card as the deposit account does not exist");
        } catch (DepositAccountMismatchCustomerException ex) {
            throw new DepositAccountMismatchCustomerException("Chosen deposit account holder does not match ATM card holder");
        }
    }
    
    @Override
    public AtmCard retrieveAtmCardByAtmCardId(Long atmCardId) throws AtmCardNotFoundException {
        AtmCard atmCard = em.find(AtmCard.class, atmCardId);
        
        if (atmCard != null) {
            return atmCard;
        } else {
            throw new AtmCardNotFoundException("Atm card ID " + atmCardId + " does not exist");
        }
    }
    
    @Override
    public AtmCard retrieveAtmCardByCardNumber(String cardNumber) throws AtmCardNotFoundException {
        Query query = em.createQuery("SELECT a FROM AtmCard a WHERE a.cardNumber = :cNumber");
        query.setParameter("cNumber", cardNumber);
        
        try {
            return (AtmCard)query.getSingleResult();
        } catch (NoResultException | NonUniqueResultException ex) {
            throw new AtmCardNotFoundException("ATM card with card number " + cardNumber + " does not exist");
        }
    }
    
    @Override
    public void deleteAtmCard(Long atmCardId) throws AtmCardNotFoundException, DeleteAtmCardException {
        AtmCard atmCardToRemove = retrieveAtmCardByAtmCardId(atmCardId);
        atmCardToRemove.getCustomer().setAtmCard(null);
        
        for (DepositAccount depositAccount : atmCardToRemove.getDepositAccounts()) {
            depositAccount.setAtmCard(null);
        }
        
        atmCardToRemove.getDepositAccounts().clear();
        
        em.remove(atmCardToRemove);
    }
    
    @Override
    public void changeAtmCardPin(Long atmCardId, String oldPin, String newPin) throws AtmCardNotFoundException, AtmCardPinMismatchException {
        AtmCard atmCardToChangePin = retrieveAtmCardByAtmCardId(atmCardId);
        
        if (oldPin.equals(atmCardToChangePin.getPin())) {
            atmCardToChangePin.setPin(newPin);
        } else {
            throw new AtmCardPinMismatchException("Old pin given is incorrect");
        }
    }
    
    @Override
    public void AtmCardVerifyPin(AtmCard atmCard, String pin) throws AtmCardInvalidPinException {
        if (pin.equals(atmCard.getPin())) {
        } else {
            throw new AtmCardInvalidPinException("Incorrect pin entered. Please try again.");
        }
    }
    
    @Override
    public List<DepositAccount> retrieveDepositAccountsByAtmCardId(Long atmCardId) throws AtmCardNotFoundException {
        AtmCard atmCard = retrieveAtmCardByAtmCardId(atmCardId);
        List<DepositAccount> atmCardDepositAccounts = atmCard.getDepositAccounts();
        atmCardDepositAccounts.size(); // Lazy fetching for remote clients
        
        return atmCardDepositAccounts;
    }
    
}
