/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejb.session.stateless;

import entity.Customer;
import entity.DepositAccount;
import java.math.BigDecimal;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import util.exception.CustomerNotFoundException;
import util.exception.DepositAccountExistException;
import util.exception.DepositAccountNotFoundException;
import util.exception.UnknownPersistenceException;

/**
 *
 * @author aaronf
 */
@Stateless
public class DepositAccountSessionBean implements DepositAccountSessionBeanRemote, DepositAccountSessionBeanLocal {

    @EJB
    private CustomerSessionBeanLocal customerSessionBeanLocal;

    @PersistenceContext(unitName = "RetailCoreBankingSystem-ejbPU")
    private EntityManager em;
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")

    public DepositAccountSessionBean() {
    }

    @Override
    public DepositAccount createNewDepositAccount(DepositAccount newDepositAccount, String customerIdentificationNumber) throws DepositAccountExistException, CustomerNotFoundException, UnknownPersistenceException {
        try {
            
            
            Customer customer = customerSessionBeanLocal.retrieveCustomerByCustomerIdentificationNumber(customerIdentificationNumber);
            
            newDepositAccount.setCustomer(customer);
            newDepositAccount.setEnabled(true);
            newDepositAccount.setHoldBalance(new BigDecimal(0));
            customer.getDepositAccounts().add(newDepositAccount);
            em.persist(newDepositAccount);
            em.flush();
            em.refresh(newDepositAccount);
            
            return newDepositAccount;
            
        }  catch (PersistenceException ex) {
            if (ex.getCause() != null && ex.getCause().getClass().getName().equals("org.eclipse.persistence.exceptions.DatabaseException")) {
                if (ex.getCause().getCause() != null && ex.getCause().getCause().getClass().getName().equals("java.sql.SQLIntegrityConstraintViolationException")) {
                    throw new DepositAccountExistException("Deposit Account with the same account number already exists");
                }
                else {
                    throw new UnknownPersistenceException(ex.getMessage());
                }
            }
            else {
                throw new UnknownPersistenceException(ex.getMessage());
            }
        } catch (CustomerNotFoundException ex) {
            throw new CustomerNotFoundException("Customer record not found in database");
        }
    }
    
    @Override
    public DepositAccount retrieveDepositAccountByDepositAccountId(Long depositAccountId) throws DepositAccountNotFoundException {
        DepositAccount depositAccount = em.find(DepositAccount.class, depositAccountId);
        if (depositAccount != null) {
            return depositAccount;
        } else {
            throw new DepositAccountNotFoundException("Deposit Account ID " + depositAccountId + "does not exist");
        }
    }
}
